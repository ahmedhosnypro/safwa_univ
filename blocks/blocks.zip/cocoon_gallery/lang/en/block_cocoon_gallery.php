<?php
$string['pluginname'] = '[Cocoon] Gallery';
$string['cocoon_gallery'] = '[Cocoon] Gallery';
$string['cocoon_gallery:addinstance'] = 'Add a new Gallery block';
$string['cocoon_gallery:myaddinstance'] = 'Add a new Gallery block to the My Moodle page';
$string['config_title'] = 'Title';
$string['config_image'] = 'Image';
