<?php
$string['configtitle'] = 'Block title';
$string['cocoon_slider_1_v:addinstance'] = 'Add a new [Cocoon] Slider style 1 block';
$string['cocoon_slider_1_v:myaddinstance'] = 'Add a new [Cocoon] Slider style 1 block to Dashboard';
$string['newcustomsliderblock'] = '[Cocoon] Slider style 1: Video';
$string['pluginname'] = '[Cocoon] Slider style 1: Video';
$string['slides_number'] = 'Number of slides';
