<?php

$string['cocoon_hero_3:addinstance'] = 'Add a new Cocoon global search block';
$string['cocoon_hero_3:myaddinstance'] = 'Add a new Cocoon global search block to Dashboard';
$string['pluginname'] = '[Cocoon] Hero 3 (with Search)';
$string['privacy:metadata'] = 'The Cocoon global search block only shows data stored in other locations.';
$string['config_title'] = 'Title';
$string['config_subtitle'] = 'Subtitle';
$string['config_feature_1_title'] = 'Title';
$string['config_feature_1_icon'] = 'Icon class';
$string['config_feature_2_title'] = 'Title';
$string['config_feature_2_icon'] = 'Icon class';
$string['config_feature_3_title'] = 'Title';
$string['config_feature_3_icon'] = 'Icon class';
$string['config_feature_4_title'] = 'Title';
$string['config_feature_4_icon'] = 'Icon class';
