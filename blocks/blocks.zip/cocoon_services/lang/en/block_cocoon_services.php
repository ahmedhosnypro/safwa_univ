<?php

$string['configtitle'] = 'Block title';
$string['cocoon_services:addinstance'] = 'Add a new [Cocoon] Services block';
$string['cocoon_services:myaddinstance'] = 'Add a new [Cocoon] Services block to Dashboard';
$string['pluginname'] = '[Cocoon] Services';
