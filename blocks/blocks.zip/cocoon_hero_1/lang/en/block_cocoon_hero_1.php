<?php
$string['pluginname'] = '[Cocoon] Hero 1';
$string['cocoon_hero_1'] = '[Cocoon] Hero 1';
$string['cocoon_hero_1:addinstance'] = 'Add a new Gallery block';
$string['cocoon_hero_1:myaddinstance'] = 'Add a new Gallery block to the My Moodle page';
$string['config_title'] = 'Title';
$string['config_subtitle'] = 'Subtitle';
$string['config_button_text'] = 'Button text';
$string['config_button_link'] = 'Button link';
$string['config_image'] = 'Image';
