<?php

$string['cocoon_featuredcourses:addinstance'] = 'Add a Cocoon featured courses block';
$string['cocoon_featuredcourses:myaddinstance'] = 'Add a Cocoon featured courses block to my moodle';
$string['pluginname'] = '[Cocoon] Featured courses';
$string['editlink'] = '<a href="{$a}">Click here to edit or add featured courses</a>';
$string['editpagedesc'] = 'Editing the list of featured courses';
$string['cocoon_featuredcourses'] = 'Cocoon featured courses';
$string['addfeaturedcourse'] = 'Add an existing course to featured list';
$string['courseid'] = 'Course';
$string['editpagetitle'] = 'Featured courses - editing';
$string['featuredcourse'] = 'Featured course: {$a}';
$string['doadd'] = 'Check to add new featured course';
$string['missingcourseid'] = 'You must select a course.';
$string['sortorder'] = 'Sort order';
$string['missingsortorder'] = 'You must set a sort order.';
$string['deletelink'] = '<a href="{$a}">Delete</a>';
$string['delete_featuredcourse'] = 'Delete featured course';
$string['confirmdelete'] = 'Are you sure you want to delete this course from the list of featured courses?';
$string['config_title'] = 'Title';
$string['config_subtitle'] = 'Subtitle';
$string['config_button_text'] = 'Button text';
$string['config_button_link'] = 'Button link';
$string['config_hover_text'] = 'Hover text';
$string['config_hover_accent'] = 'Hover accent';
