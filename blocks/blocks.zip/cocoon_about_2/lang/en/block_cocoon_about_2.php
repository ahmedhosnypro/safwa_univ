<?php
$string['pluginname'] = '[Cocoon] About (Text 2 Columns)';
$string['cocoon_about_2'] = '[Cocoon] About (Text 2 Columns)';
$string['cocoon_about_2:addinstance'] = 'Add a new about block with text columns';
$string['cocoon_about_2:myaddinstance'] = 'Add a new about block with text columns to the My Moodle page';
$string['config_col_1_header'] = 'Column 1';
$string['config_col_1_title'] = 'Title';
$string['config_col_1_body'] = 'Body';
$string['config_col_2_header'] = 'Column 2';
$string['config_col_2_title'] = 'Title';
$string['config_col_2_body'] = 'Body';
