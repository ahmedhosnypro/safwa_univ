<?php

$string['configtitle'] = 'Block title';
$string['cocoon_pills:addinstance'] = 'Add a new Custom slider block';
$string['cocoon_pills:myaddinstance'] = 'Add a new Custom slider block to Dashboard';
$string['leaveblanktohide'] = 'leave blank to hide the title';
$string['newcustomsliderblock'] = '(new Custom slider block)';
$string['pluginname'] = '[Cocoon] Pills';

$string['slides_number'] = 'Number of slides';
$string['config_slide_title'] = 'Title';
$string['config_slide_subtitle'] = 'Subtitle';
$string['config_slide_btn_text'] = 'Button text';
$string['config_slide_btn_link'] = 'Button link';
$string['config_file_slide'] = 'Image';
