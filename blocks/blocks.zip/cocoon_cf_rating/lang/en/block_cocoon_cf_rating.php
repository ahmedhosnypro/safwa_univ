<?php

$string['cocoon_cf_rating:addinstance'] = 'Add a new [Cocoon] Course Filter (Rating) block';
$string['cocoon_cf_rating:myaddinstance'] = 'Add a new [Cocoon] Course Filter (Rating) block to Dashboard';
$string['pluginname'] = '[Cocoon] Course Filter (Rating)';
