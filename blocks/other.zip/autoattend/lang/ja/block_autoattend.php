<?php // $Id$ 
      // block_autoattend.php - created with Moodle 1.7.1+ (2006101010)

$string['pluginname'] = '自動出欠ブロック';
$string['autoattend:addinstance'] = '自動出欠ブロックを追加する';
$string['autoattend:myaddinstance'] = '自動出欠ブロックを追加する';
$string['privacy:metadata'] = 'The Auto Attendance block only shows data stored in other locations.';

$string['autoattend:view'] = 'ブロックの閲覧';

$string['Amethod'] = '自';
$string['Amethodfull'] = '自動';
$string['Cstate'] = '了';
$string['Cstatefull'] = '完了';
$string['Mmethod'] = '手';
$string['Mmethodfull'] = '手動';
$string['Ostate'] = '続';
$string['Ostatefull'] = '点呼中';
$string['Smethod'] = '半';
$string['Smethodfull'] = '半自動';

$string['Pacronym'] = '出';
$string['Xacronym'] = '欠';
$string['Lacronym'] = '遅';
$string['Eacronym'] = '早';
$string['Yacronym'] = '未';
$string['Gacronym'] = '汎';
$string['Sacronym'] = '特';

$string['Ptitle'] = '出';
$string['Xtitle'] = '欠';
$string['Ltitle'] = '遅';
$string['Etitle'] = '早';
$string['Ytitle'] = '未';
$string['Gtitle'] = '汎';
$string['Stitle'] = '特';

$string['Pdesc']  = '出席';
$string['Xdesc']  = '欠席';
$string['Edesc']  = '早退';
$string['Ldesc']  = '遅刻';
$string['Ydesc']  = '未了';
$string['Gdesc']  = '汎用';
$string['Sdesc']  = '特別';
$string['Adesc']  = '全ての出欠';
$string['Zdesc']  = '欠席または未了';

$string['status'] = '出欠';
$string['order'] = '順';
$string['Dmethod'] = '未';
$string['Dmethodfull'] = '未点呼';
$string['Nstate'] = '未';
$string['Nstatefull'] = '未点呼';
$string['about'] = 'アバウト';
$string['acronym'] = '頭文字';
$string['title'] = 'タイトル';
$string['add'] = '登録';
$string['add_session'] = '授業登録';
$string['add_multi'] = '登録（複数）';
$string['add_one'] = '登録（1項目）';
$string['addmultiplesessions'] = '複数の授業を登録';
$string['addsession'] = '授業を登録';
$string['alltaken'] = '全期間';
$string['attendance'] = '出欠';
$string['attendanceconfrm'] = '出席確認';
$string['attenderror'] = '出欠の記録中にエラーが発生しました';
$string['attendforsession'] = '授業の出欠表';
$string['attendforthecourse'] = 'コース全体の出欠表';
$string['attendforuser'] = 'ユーザ個人の出欠表';
$string['attendgrade'] = '出席点';
$string['attendgradeshort'] = '点';
$string['attenddata'] = '出欠データ';
$string['attendkey'] = '出欠キー';
$string['attendkey_help'] = '半自動モードで出欠を取る場合，学生が入力すべきキーワード（アルファベット）を指定します．
「ランダムキー」にチェックを入れた場合は，5文字の小文字が自動生成されます．<br />
自動モード・手動モードの場合は，設定しても無視されます．';

$string['attendnotstarted'] = 'このコースに対する出欠確認は，まだ開始されていません';
$string['attendpercent'] = '出席率';
$string['attendreport'] = '出欠レポート';
$string['attendsubmiterr'] = '出席を送信できませんでした';
$string['attendsubmitted'] = '出席が送信されました';
$string['attendsuccess'] = '出欠が正常に取られました';
$string['attendtable'] = '出欠表';
$string['sessiontable'] = '授業一覧';
$string['attendupdated'] = '出欠表が正常に更新されました';
$string['autoattend'] = '自動出欠管理';
$string['autoattendblock'] = '自動出欠管理';
$string['calleddate'] = '日時';
$string['calledtime'] = '時刻';
$string['callmethod'] = '手法';
$string['callstate'] = '点呼状態';
$string['changesession'] = '授業の変更';
$string['updatesession'] = '授業の更新';
$string['clearall'] = '選択の解除';
$string['correctuser'] = '修正';
$string['courseidwrong'] = '不正なコースIDです';
$string['coursename'] = 'コース名';
$string['createmultiplesessions'] = '複数の授業を登録する';
$string['createonesession'] = '授業を登録する';
$string['defaults'] = 'デフォルト';
$string['delete'] = '削除';
$string['deleteconfirm'] = '本当に以下の授業登録を削除しますか？';
$string['deleteok'] = '削除';
$string['deleteselect'] = '選択したものを削除';
$string['deletesession'] = '授業登録の削除';
$string['deletingsession'] = 'コースの授業登録を削除';
$string['denysameip'] = '同一IPの禁止';
$string['description'] = '説明';
$string['display'] = '表示';
$string['downloadexcel'] = 'Excel でダウンロード';
$string['downloadtext']  = 'テキストでダウンロード';
$string['duration_hour'] = '時間';
$string['editsession'] = '授業情報の編集';
$string['endtime'] = '終了時刻';
$string['errorinaddingsession'] = '授業の登録中にエラーが発生しました';
$string['erroringeneratingsessions'] = '授業の登録中にエラーが発生しました';
$string['grade'] = '点';
$string['hourmin'] = '時, 分';
$string['hour'] = '時';
$string['hours'] = '時間';
$string['minute'] = '分';
$string['indetail'] = '詳細 ...';
$string['ipaddress'] = 'IPアドレス';
$string['ip'] = 'IP';
$string['iperrattention'] = 'もしWebプロキシを使用しているなら，このページに対してはプロキシを外してください．';
$string['iperroccur'] = 'IPアドレスのエラー';
$string['keyerrattention'] = 'キーワードを確認して，もう一度試してください．';
$string['keyerroccur'] = 'キーワードのエラー';
$string['keyword'] = 'キー';
$string['mismatchip'] = '貴方のパソコンのIPアドレスからは出席を送信することはできません．貴方のパソコンのIPアドレス:';
$string['mismatchkey'] = 'キーワードの不一致';
$string['missinfo'] = '必要な情報が設定されていません';
$string['myvariables'] = '出欠評点の設定';
$string['needkeyword'] = 'この出席を送信するにはキーワードが必要です．出欠キーワードを確認してください．';
$string['nevererror'] = '起こりえないエラー．恐らくはプログラムのバグです．';
$string['noattforuser'] = 'ユーザが存在しません';
$string['nodescription'] = 'なし';
$string['noofdaysabsent'] = '欠席数';
$string['noofdaysexcused'] = '早退数';
$string['noofdayslate'] = '遅刻数';
$string['noofdayspresent'] = '出席数';
$string['nosessiondayselected'] = '授業日が選択されませんでした';
$string['nosessionexists'] = 'このコースにはまだ授業が登録されていません<br />
最初に「登録」タブで授業を登録してください';
$string['nosuchsession'] = 'このコースにはそのような授業は存在しません';
$string['nosuchuser'] = 'このユーザはこのコースに登録されていません';
$string['notaccessguest'] = 'ゲストはこのページにはアクセスできません';
$string['notaccessstudent'] = '学生はこのページにアクセスする事はできません';
$string['notaccessnoteacher'] = '教師以外はこのページにアクセスする事はできません';
$string['notaccessnoadmin'] = '管理者以外はこのページにアクセスする事はできません';
$string['notcallthis'] = '不正な方法によってページにアクセスしました';
$string['novalue'] = '−';
$string['olddate'] = '旧授業実施日';
$string['newdate'] = '新授業実施日';
$string['oldsessionendtime'] = '旧授業終了時刻';
$string['newsessionendtime'] = '新授業終了時刻';
$string['oldsessionlatetime'] = '旧遅刻許容時間';
$string['newsessionlatetime'] = '新遅刻許容時間';
$string['oldsessionmethod'] = '旧出欠確認方法';
$string['newsessionmethod'] = '新出欠確認方法';
$string['oldsessionstarttime'] = '旧授業開始時刻';
$string['newsessionstarttime'] = '新授業開始時刻';
$string['oldsessionduration'] = '旧授業時間';
$string['newsessionduration'] = '新授業時間';
$string['period'] = '間隔';
$string['refreshdata'] = ' リフレッシュ ';
$string['recalcgrades'] = '評定の再計算';
$string['remarks'] = '備考';
$string['report'] = '出欠レポート';
$string['reqinfomiss'] = '要求された情報は存在しません';
$string['restoredefaults'] = 'デフォルトをリストアする';
$string['return'] = '戻る';
$string['returnbutton'] = ' 戻る ';
$string['returntoN'] = '未点呼状態へ戻る';
$string['returntoNconfirm'] = '本当に未点呼の状態に戻りますか？';
$string['returntoNdesc'] = '未点呼の状態に戻しても，手動，半自動モードでの授業の出欠は変化しません．';
$string['sameusedip'] = '貴方のパソコンのIPアドレスは既に他のユーザの出席送信で使用されています．<br />同一のパソコンからこの出席を送信することはできません．貴方のパソコンのIPアドレス:';
$string['sdaysmiss'] = '曜日が選択されていません';
$string['selectall'] = '全てを選択';
$string['semiautoattend'] = '半自動モード';
$string['semiautoconfirm'] = '貴方は以下の授業の出席を送信することができます．出席を送信しますか？';
$string['session'] = '出欠';
$string['sessionadded'] = '授業が正常に登録されました';
$string['sessionallowip'] = '教室のIP';
$string['sessionallowip_help'] = '出欠を許可する端末のIPアドレスの範囲を指定します．
基本的には「IPアドレス/サブネットマスク」の形式を空白またはカンマで区切って並べたものですが，以下の形式も使用することが可能です．<br />
<br />
・サブネットマスクの代わりにプレフィックス長表記も可能<br />
&nbsp;&nbsp;&nbsp;&nbsp;202.26.155.0/16 => 202.26.0.0/255.255.0.0 <br />
<br />
・IPアドレスを一部省略した場合，省略された部分は 0 と見なされる<br />
&nbsp;&nbsp;&nbsp;&nbsp;202.26./255.255.255.0 => 202.26.0.0/255.255.255.0<br />
<br />
・サブネットマスクを一部省略した場合，省略された部分は 0 と見なされる<br />
&nbsp;&nbsp;&nbsp;&nbsp;202.26.100.2/255.255. => 202.26.0.0/255.255.0.0 <br />
&nbsp;&nbsp;&nbsp;&nbsp;202.26./255.255.255. => 202.26.0.0/255.255.255.0<br />
<br />
・サブネットマスクを全て省略した場合，IPアドレスで省略された部分が 0 と見なされる<br />
&nbsp;&nbsp;&nbsp;&nbsp;202. => 202.0.0.0/255.0.0.0<br />
<br />
例） 192.168.100. 202.26.144.0/255.255.255. 202.26.148.122 ';

$string['sessionalreadyexists'] = 'この日のこの時刻には既に授業が設定されています';
$string['sessiondate'] = '授業実施日';
$string['sessiondays'] = '授業の曜日';
$string['sessiondeleted'] = '授業が正常に削除されました';
$string['sessionenddate'] = '授業終了日';
$string['sessionendtime'] = '授業終了時刻';
$string['sessionexist'] = '授業は登録されませんでした！ (すでに登録されています)';
$string['sessionmulti'] = '複数のセッションを登録する';
$string['sessionlatetime'] = '遅刻許容時間';
$string['sessionmethod'] = '出欠確認方法';
$string['sessionscompleted'] = '点呼完了';
$string['sessionsgenerated'] = '授業が正常に登録されました';
$string['sessionsnogenerated'] = '生成された出欠は一つもありません';
$string['sessionstartdate'] = '授業開始日';
$string['sessionstarttime'] = '授業開始時刻';
$string['sessionupdated'] = '授業情報が正常に更新されました';
$string['sessionupdateerror'] = '授業情報の更新でエラーが発生しました';
$string['sessionduration'] = '授業時間';
$string['setrandomkey'] = 'ランダムキー';
$string['grade_settings'] = '評点設定';
$string['showdefaults'] = 'デフォルトを表示する';
$string['starttime'] = '開始時刻';

$string['strftimedmshort'] = '%m/%d';
$string['strftimedm'] = '%m月%d日';
$string['strftimedmy'] = '%Y年%m月%d日';
$string['strftimedmyw'] = '%m月%d日(%a)';
$string['strftimeshortdate'] = '%Y/%m/%d';
$string['strftimehourmin'] = '%H時%M分';
$string['strftimehmshort'] = '%H:%M';
$string['strftimefull'] = '%Y年%m月%d日 %H時%M分';
$string['strftimecalled'] = '%H:%M (%m/%d)';

$string['studentid'] = '学籍番号';
$string['submitattend'] = '出席の送信';
$string['submitok'] = '送信';
$string['takeattendance'] = '出欠を取る';
$string['takemanualattend'] = '出欠管理';
$string['toNok'] = 'はい';
$string['toNtitle'] = '未点呼状態へ';
$string['update'] = '更新';
$string['updateordel'] = '更新または削除';
$string['updatesessionattend'] = '講義の出欠更新';
$string['updatesessioninfo'] = '講義情報の更新';
$string['updateuserattend'] = '学生の出欠更新';
$string['variablesupdated'] = '評点変数が正常に更新されました';
$string['variablesupdateerror'] = '評点変数の更新でエラーが発生しました';
$string['forprinting'] = '印刷画面';
$string['months'] = '月';
$string['week'] = '週';
$string['weeks'] = '週';
$string['everyweeks']  = '週ごと';
$string['everymonths'] = '月ごと';
$string['wrongdatesselected'] = '間違った日付が選択されました';
$string['wrongtimesselected'] = '間違った時刻が選択されました';
$string['returnto_course'] = 'コースに戻る';

$string['class_settings'] = 'クラス定義';
$string['classname'] = 'クラス';
$string['allclasses'] = '全クラス';
$string['validclasses'] = '有効クラス';
$string['nonclass'] = 'クラスなし';
$string['unknownclass'] = 'クラス不明';
$string['changeclass'] = 'クラス変更';
$string['class_division'] = 'クラス分け';
$string['deletingclasses'] = 'クラスの削除';
$string['deleteconfirmclasses'] = '既に出欠が取られているクラスが存在します．<br ?>それらを本当に削除しますか？';
$string['students_list'] = 'ユーザリスト';

//New: grouping
$string['choosegrouping'] = 'グルーピングの選択';
$string['choosegrouping_help'] = 'グルーピングの選択．グルーピングに含まれるグループを新しいクラスとして自動生成することができます．グループ内のユーザは自動的にクラスに含まれます．';
$string['allgrouping'] = '全てのグループ';
//--

$string['allstudents'] = '全学生用';
$string['exclusion'] = '出欠から除外';
$string['excludedstudents'] = '除外学生';

$string['monday']  = '月曜';
$string['tuesday'] = '火曜';
$string['wednesday'] = '水曜';
$string['thursday'] = '木曜';
$string['friday'] = '金曜';
$string['saturday'] = '土曜';
$string['sunday'] = '日曜';

$string['nowtime'] = '現在の時刻';
$string['nowtime_help'] = 'この時刻表示が現在の時刻と一致していない場合，この自動出欠ブロック全体の時刻表示は不正確になります．<br />
もしどうしても時刻が一致しない場合は，PHP の設定ファイルである php.ini でタイムゾーン (date.timezone) も確認してください．';

$string['wiki_url'] = 'http://docs.moodle.org/2x/ja/Autoattendance_block';

$string['ipresolv'] = 'IPアドレスの逆引きURL';
$string['ipresolv_desc'] = '学生の接続元のIPアドレスを逆引きするためのURLを指定します．IPアドレス部分は %s と記述します';
$string['ipresolv_url']  = 'http://wq.apnic.net/apnic-bin/whois.pl?searchtext=%s';

$string['use_timeoffset'] = 'タイムゾーン情報の使用';
$string['use_timeoffset_desc'] = '管理者の時刻設定にタイムゾーン情報を反映します';

$string['output_idnumber'] = 'idnumber の出力/表示';
$string['output_idnumber_desc'] = 'ダウンロードデータやレポートに学生の idnumberを表示します';

$string['page_row_size'] = 'ページの行数';
$string['page_row_size_desc'] = 'この行数ごとにヘッダが表示されます．';
$string['page_column_size'] = 'ページの列数';
$string['page_column_size_desc'] = 'この列数ごとにユーザ名が表示されます．';

$string['feedback'] = 'アンケート';
$string['pleasefeedback'] = 'アンケートにご協力ください';
$string['removefeedback'] = '（このリンクは mod_autoattendmod 自動出欠モジュールの設定で非表示にできます）';

$string['repairdb'] = 'DBの修復';
$string['repairdbok'] = '修復する';
$string['repaireddb'] = 'DBを修復しました．';
$string['repairdb_confirm'] = 'DBの修復を行いますか？';

$string['email_teacher_attend'] = 'このメールには {$a->fullname} [{$a->date} {$a->starttm}-{$a->endtm}] の出欠データが添付されています．';
$string['email_teacher_key']    =   '{$a->fullname} [{$a->date} {$a->starttm}-{$a->endtm}] の出欠キーワードは {$a->key} です．';
$string['email_teacher_key_html'] = '{$a->fullname} [{$a->date} {$a->starttm}-{$a->endtm}] の出欠キーワードは <strong>{$a->key}</strong> です．';
$string['email_user_attend_P'] = '{$a->fullname} [{$a->date} {$a->starttm}-{$a->endtm}] の出欠は「出席」として登録されました．';
$string['email_user_attend_L'] = '{$a->fullname} [{$a->date} {$a->starttm}-{$a->endtm}] の出欠は「遅刻」として登録されました．';
$string['email_user_attend_X'] = '{$a->fullname} [{$a->date} {$a->starttm}-{$a->endtm}] の出欠は「欠席」として登録されました．';
$string['email_user_attend_C'] = '{$a->fullname} [{$a->date} {$a->starttm}-{$a->endtm}] の出席状態が変更されました．Webサイトで確認してください．';

//
$string['maintenance'] = 'メンテナンス';
$string['settingpairmod']  = '<strong>モジュール (mod_autoattedmod) の設定</strong>';
$string['instancepairmod'] = '<strong>このコースにモジュール (mod_autoattendmod) のインスタンスを作成してください</strong>';
$string['installpairmod']  = '<strong>モジュール (mod_autoattendmod) をインストールしてください</strong>';

$string['cleanupdb'] = 'DBのクリーンアップ';
$string['cleanupdbok'] = 'クリーンアップする';
$string['cleanupeddb'] = 'DBをクリーンアップしました．';
$string['cleanupdb_confirm'] = 'DBのクリーンアップを行いますか？';
$string['cleanupdb_help'] = '既に削除されたコースの授業データを削除します．削除された授業データの出欠データも同時に削除します．<br />
この機能は管理者のみ実行可能です．';

$string['deletedb'] = '古い授業データの削除';
$string['deletedbok'] = '古い授業データを削除する';
$string['deleteddb'] = '古い授業データを削除しました．';
$string['deletedb_title'] = '指定された日付より前のい授業データを削除する';
$string['deletedb_info'] = '<strong>{$a->delstr}</strong> 以前の削除対象の授業データは <strong>{$a->delnum}</strong>個 です．';
$string['deletedb_confirm'] = '古い授業データの削除を行いますか？';
$string['deletedb_confirm_2nd'] = '本当に古いデータを削除しますか？';
$string['deletedb_help'] = '指定された日付より古い授業データを削除します．削除された授業データの出欠データも同時に削除します．<br />
この処理には非常に長い時間が掛かる場合があります．<br />
この機能は管理者のみ実行可能です．';

$string['sessionsummertime']    = '夏時間';
$string['oldsessionsummertime'] = '旧夏時間';
$string['newsessionsummertime'] = '新夏時間';

// date format
$string['date_1st_name'] = 'year';
$string['date_2nd_name'] = 'month';
$string['date_3rd_name'] = 'day';

