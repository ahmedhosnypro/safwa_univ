# Edwiser Site Importer

This plugin add functionality in Edwiser RemUI to import content from demo sites.